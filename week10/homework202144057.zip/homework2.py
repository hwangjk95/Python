import os

path_name = "c:/202144057"
full_filename = path_name + "/list.txt"

if os.path.isfile(full_filename):
    f = open(full_filename,'r')
    
    scores=[]
    while True:
        line=f.readline()
        if not line:
            break
        
        a=line.split(',')
        if len(a) == 4:
            score={}
            score['name']=a[0]
            score['kor']=a[1]
            score['eng']=a[2]
            score['mat']=a[3]
            for key,value in score.items():
                scores.append=f"{key}:{value}\t"
                
            f.close
            
# for n in scores.items():
#     print
            